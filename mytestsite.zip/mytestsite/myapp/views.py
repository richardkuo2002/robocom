from django.shortcuts import render
from module import func

# Create your views here.

MainTarget = ""


def test(request):
    output = str(func.GetDock())
    func.MoveTo(1)
    output += str(func.GetAGV()["value"]["agv"][0][6])
    return render(request, "page.html", locals()) 

def move(request, target):
    # 增加check是否到達Target function 
    AiStatus = func.GetAGV()["value"]["agv"][0][6]
    # if AiStatus == "error":
    #     return render(request, "report.html", locals())
    # if AiStatus == "end":
    #     return render(request, "choose.html", locals())
    if AiStatus == "standby":
        func.MoveTo(target)
    print(target)
    return render(request, "move.html", locals())

def choose(request):
    return render(request, "choose.html", locals())

def report(request):
    return render(request, "report.html", locals())


